#!/bin/bash

cd
sudo apt update -y
apt update -y
sudo apt install git -y
apt install git -y
cd
mkdir /root/Mantap/
cd /root/Mantap/
git clone https://github.com/fisabiliyusri/Mantap

cd
